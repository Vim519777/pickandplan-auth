import { useEffect, useState } from 'react'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(import.meta.env.VITE_SUPABASE_URL, import.meta.env.VITE_SUPABASE_ANON_KEY)

function App() {
  const [session, setSession] = useState(null)

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
    })

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session)
    })

    return () => {
      listener.subscription.unsubscribe()
    }
  }, [])

  const loginWithGoogle = async () => {
    await supabase.auth.signInWithOAuth({ provider: 'google' })
  }

  const logout = async () => {
    await supabase.auth.signOut()
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      {!session ? (
        <button className="bg-black text-white px-6 py-3 rounded-lg shadow-md hover:bg-gray-800" onClick={loginWithGoogle}>
          Sign in with Google
        </button>
      ) : (
        <div className="text-center">
          <p className="mb-4 text-lg">Welcome, {session.user.email}</p>
          <button className="bg-red-500 text-white px-6 py-2 rounded-md hover:bg-red-600" onClick={logout}>
            Sign Out
          </button>
        </div>
      )}
    </div>
  )
}

export default App
